package com.okta.mongodb.springdockerrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDockerRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
