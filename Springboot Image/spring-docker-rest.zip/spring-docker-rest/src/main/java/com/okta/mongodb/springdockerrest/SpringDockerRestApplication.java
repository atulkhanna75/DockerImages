package com.okta.mongodb.springdockerrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDockerRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDockerRestApplication.class, args);
	}

}
